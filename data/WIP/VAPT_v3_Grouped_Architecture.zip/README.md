
# VAPT WordPress Protection Suite
## v3.0 — Grouped Enforcer Architecture

This package restructures Apache .htaccess risk enforcement from per-risk writing
to group-based block writing.

## Structure

/vapt-patterns
  - index.json
  - group_*.json

/vapt-driver
  - driver_manifest_v3.json

## Execution Flow

Enabled Risks → Group Resolver → Merge Strategy → Single Block Per Group → Write

## Benefits

- Reduced duplication
- Cleaner rollback
- Fewer rewrite conflicts
- Performance improvement
- Logical separation of enforcement concerns

Version: 3.0.0
